import pygame
import sys
import numpy as np

# 初始化Pygame
pygame.init()

# 游戏界面配置
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 600
LINE_COLOR = (0, 0, 0)  # 线条颜色
BOARD_COLOR = (255, 204, 102)  # 棋盘颜色
GRID_SIZE = 30  # 每个格子的大小
GRID_COUNT = 19  # 棋盘格子数

# 初始化游戏窗口
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('五子棋')

# 创建棋盘
board = np.zeros((GRID_COUNT, GRID_COUNT), dtype=int)

# 定义颜色
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
CURSOR_COLOR = (0, 0, 255)  # 光标颜色

# 游戏主循环
def main():
    turn = 0  # 0: 黑棋  1: 白棋
    game_over = False
    winner = None
    cursor_pos = (0, 0)  # 光标位置
    
    while not game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if turn == 0:
                    place_piece(board, cursor_pos, 1)
                    turn = 1
                else:
                    place_piece(board, cursor_pos, 2)
                    turn = 0
                    
                winner = check_winner(board)
                if winner is not None:
                    game_over = True
            
            elif event.type == pygame.MOUSEMOTION:
                x, y = event.pos
                cursor_pos = get_closest_intersection(x, y)
        
        draw_board(board)
        draw_cursor(cursor_pos)
        pygame.display.flip()

    print(f"游戏结束，胜利者是 {'黑棋' if winner == 1 else '白棋'}！")
    pygame.quit()
    sys.exit()

# 绘制棋盘
def draw_board(board):
    screen.fill(BOARD_COLOR)
    
    # 绘制棋盘网格
    for i in range(GRID_COUNT):
        pygame.draw.line(screen, LINE_COLOR, (GRID_SIZE, GRID_SIZE * (i + 1)), 
                         (GRID_SIZE * GRID_COUNT - GRID_SIZE, GRID_SIZE * (i + 1)), 2)
        pygame.draw.line(screen, LINE_COLOR, (GRID_SIZE * (i + 1), GRID_SIZE), 
                         (GRID_SIZE * (i + 1), GRID_SIZE * GRID_COUNT - GRID_SIZE), 2)

    # 绘制棋子
    for i in range(GRID_COUNT):
        for j in range(GRID_COUNT):
            if board[i][j] == 1:
                pygame.draw.circle(screen, BLACK, (GRID_SIZE * (j + 1), GRID_SIZE * (i + 1)), GRID_SIZE // 2 - 2)
            elif board[i][j] == 2:
                pygame.draw.circle(screen, WHITE, (GRID_SIZE * (j + 1), GRID_SIZE * (i + 1)), GRID_SIZE // 2 - 2)

# 绘制光标
def draw_cursor(pos):
    if pos is not None:
        i, j = pos
        pygame.draw.circle(screen, CURSOR_COLOR, (GRID_SIZE * (j + 1), GRID_SIZE * (i + 1)), 5)

# 下棋
def place_piece(board, pos, player):
    i, j = pos
    if board[i][j] == 0:
        board[i][j] = player

# 检查胜者
def check_winner(board):
    directions = [(0, 1), (1, 0), (1, 1), (1, -1)]  # 横、竖、斜、反斜

    for i in range(GRID_COUNT):
        for j in range(GRID_COUNT):
            if board[i][j] != 0:
                for d in directions:
                    if check_five(board, i, j, d):
                        return board[i][j]
    return None

# 检查是否有五子连珠
def check_five(board, i, j, direction):
    count = 1
    current = board[i][j]
    x, y = direction
    
    # 正向检查
    for k in range(1, 5):
        ni = i + x * k
        nj = j + y * k
        if 0 <= ni < GRID_COUNT and 0 <= nj < GRID_COUNT and board[ni][nj] == current:
            count += 1
        else:
            break
    
    # 反向检查
    for k in range(1, 5):
        ni = i - x * k
        nj = j - y * k
        if 0 <= ni < GRID_COUNT and 0 <= nj < GRID_COUNT and board[ni][nj] == current:
            count += 1
        else:
            break
    
    return count >= 5

# 获取离鼠标最近的交叉点
def get_closest_intersection(mouse_x, mouse_y):
    i = round((mouse_y - GRID_SIZE) / GRID_SIZE)
    j = round((mouse_x - GRID_SIZE) / GRID_SIZE)
    
    # 限制在棋盘范围内
    i = max(0, min(GRID_COUNT - 1, i))
    j = max(0, min(GRID_COUNT - 1, j))
    
    return (i, j)

if __name__ == '__main__':
    main()